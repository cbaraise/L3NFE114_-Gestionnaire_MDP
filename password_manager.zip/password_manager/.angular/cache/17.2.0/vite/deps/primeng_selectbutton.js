import {
  SELECTBUTTON_VALUE_ACCESSOR,
  SelectButton,
  SelectButtonModule
} from "./chunk-EKRI5Q2Q.js";
import "./chunk-S2AZBDXB.js";
import "./chunk-7EFQWFRS.js";
import "./chunk-TGUZRQB5.js";
import "./chunk-TKJMWDM5.js";
import "./chunk-C3H73MNQ.js";
import "./chunk-EVZ7MBMK.js";
import "./chunk-QHIF2FQR.js";
import "./chunk-UKEHM6V6.js";
import "./chunk-V2DXGMIT.js";
import "./chunk-ZDOIMVJD.js";
export {
  SELECTBUTTON_VALUE_ACCESSOR,
  SelectButton,
  SelectButtonModule
};
//# sourceMappingURL=primeng_selectbutton.js.map
