import {
  InputText,
  InputTextModule
} from "./chunk-HFDTZ4DJ.js";
import "./chunk-S2AZBDXB.js";
import "./chunk-C3H73MNQ.js";
import "./chunk-EVZ7MBMK.js";
import "./chunk-QHIF2FQR.js";
import "./chunk-UKEHM6V6.js";
import "./chunk-V2DXGMIT.js";
import "./chunk-ZDOIMVJD.js";
export {
  InputText,
  InputTextModule
};
//# sourceMappingURL=primeng_inputtext.js.map
