import {
  Tooltip,
  TooltipModule
} from "./chunk-3W4WO3F7.js";
import "./chunk-TKJMWDM5.js";
import "./chunk-C3H73MNQ.js";
import "./chunk-EVZ7MBMK.js";
import "./chunk-QHIF2FQR.js";
import "./chunk-UKEHM6V6.js";
import "./chunk-V2DXGMIT.js";
import "./chunk-ZDOIMVJD.js";
export {
  Tooltip,
  TooltipModule
};
//# sourceMappingURL=primeng_tooltip.js.map
