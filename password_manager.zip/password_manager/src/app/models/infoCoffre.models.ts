export interface infoCoffre{
    email:string,
    note:string,
    password:string,
    sitename:string,
    urllogo:string,
    urlsite:string,
    username:string,
    uuidCoffre:string
}