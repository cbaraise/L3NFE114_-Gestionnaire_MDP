export interface addCategorie{
    message:string,
    status:string
}