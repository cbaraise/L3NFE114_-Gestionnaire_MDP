export interface changePass{
    message:string;
    status:string
}