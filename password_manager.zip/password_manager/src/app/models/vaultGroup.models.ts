export interface vaultGroup{
    Nom:string,
    uuidGroupe:string
}

