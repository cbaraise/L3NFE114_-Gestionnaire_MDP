export interface logout{
    msg:string
}