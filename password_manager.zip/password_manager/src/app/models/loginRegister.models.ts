
export interface loginRegister{
    status:string;
    message:string;
    access_token:string;
    isAdmin:number;
    username:string;
}