export interface vaultListe{
    urllogo:string,
    urlsite:string,
    uuidCoffre:string,
    sitename:string
}