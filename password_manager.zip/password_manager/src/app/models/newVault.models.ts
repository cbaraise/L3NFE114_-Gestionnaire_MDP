export interface newVault{
    uuidcategori : string,
    usernam : string,
    email: string,
    password: string,
    sitenam : string,
    urlsite: string,
    urllogo: string,
    note: string
}