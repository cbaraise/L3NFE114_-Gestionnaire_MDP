export interface passwordforget{
    message:string;
    status:string

}