export interface otpCode{
    message:string,
    status:string,
    urlreset:string

}