export interface adminAllPassword{
    coffres:coffres[],
    status:string
}



export interface coffres{
    password:string
    urllogo:string
    urlsite:string
    username:string
}
