export interface categories{
    idCategorie: string,
    libCategorie: string
}
