export interface secretkey{
    key:string,
    status:string
}