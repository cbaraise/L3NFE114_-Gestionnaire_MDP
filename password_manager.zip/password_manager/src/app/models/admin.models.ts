export interface admin{
    status:string,
    users:users[]
}

export interface users{
    email:string,
    username:string
}