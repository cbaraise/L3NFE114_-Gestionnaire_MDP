
export const environnement = {
    production:false,
    baseUri:'http://127.0.0.1:8080'
}