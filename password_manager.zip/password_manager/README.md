→Pour lancer l'API:
cd chemin/Répertoire/Projet
venv\Scripts\activate
python -m flask --app __init__ run --debug -p 8080




→lorsque vous lancer le projet angular: 
npm install

→lancer le server local:
ng serve

